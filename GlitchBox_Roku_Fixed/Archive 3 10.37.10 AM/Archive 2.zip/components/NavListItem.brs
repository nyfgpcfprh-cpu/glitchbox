sub init()
    m.bg = m.top.findNode("bg")
    m.label = m.top.findNode("label")

    m.top.observeField("itemContent", "onContentChanged")
    m.top.observeField("itemHasFocus", "onFocusChanged")
    m.top.observeField("focusPercent", "onFocusChanged")

    updateFromContent()
    updateFocus()
end sub

sub onContentChanged()
    updateFromContent()
end sub

sub onFocusChanged()
    updateFocus()
end sub

sub updateFromContent()
    item = m.top.itemContent
    if item <> invalid and item.title <> invalid then
        m.label.text = item.title
    else
        m.label.text = ""
    end if
end sub

sub updateFocus()
    focused = m.top.itemHasFocus
    if focused = invalid then
        fp = m.top.focusPercent
        focused = (fp <> invalid and fp > 0)
    end if
    if m.bg <> invalid then m.bg.visible = focused
    if m.label <> invalid then
        if focused then
            m.label.color = "#0B0B10"
        else
            m.label.color = "#B8B8C5"
        end if
    end if
end sub
