sub init()
    m.home = m.top.findNode("homeScene")
    m.details = m.top.findNode("detailsScene")
    m.library = m.top.findNode("libraryScene")
    m.player = m.top.findNode("playerScene")
    m.settings = m.top.findNode("settingsScene")
    m.search = m.top.findNode("searchScene")

    if m.home <> invalid then
        m.home.observeField("openSettings", "onOpenSettings")
        m.home.observeField("openSearch", "onOpenSearch")
    end if

    if m.settings <> invalid then m.settings.observeField("backRequested", "onSettingsBack")
    if m.search <> invalid then m.search.observeField("backRequested", "onSearchBack")
    if m.player <> invalid then m.player.observeField("backRequested", "onPlayerBack")
    if m.details <> invalid then m.details.observeField("backRequested", "onDetailsBack")

    m.top.setFocus(true)
    showHome()
end sub

sub showHome()
    if m.home <> invalid then m.home.visible = true
    if m.details <> invalid then m.details.visible = false
    if m.library <> invalid then m.library.visible = false
    if m.player <> invalid then m.player.visible = false
    if m.settings <> invalid then m.settings.visible = false
    if m.search <> invalid then m.search.visible = false

    ' Give focus to the Home scene, then to a focusable child (nav list / rows)
    if m.home <> invalid then m.home.setFocus(true)
    focusHomeDefault()
end sub

sub onOpenSettings(event as Object)
    ' Only react when HomeScene signals true
    if event <> invalid and event.getData() <> true then return

    if m.home <> invalid then
        m.home.openSettings = false
        m.home.visible = false
    end if

    ' Hide any other scenes that might be visible
    if m.details <> invalid then m.details.visible = false
    if m.library <> invalid then m.library.visible = false
    if m.player <> invalid then m.player.visible = false
    if m.search <> invalid then m.search.visible = false

    if m.settings <> invalid then
        m.settings.visible = true
        m.settings.setFocus(true)

        ' Force focus to SettingsScene's ButtonGroup so remote works immediately
        actions = m.settings.findNode("actions")
        if actions <> invalid then actions.setFocus(true)
    end if
end sub
sub onSettingsBack(event as Object)
    if event <> invalid and event.getData() <> true then return

    if m.settings <> invalid then
        m.settings.backRequested = false
        m.settings.visible = false
    end if
    showHome()
end sub

sub onOpenSearch(event as Object)
    ' Only react when HomeScene signals true
    if event <> invalid and event.getData() <> true then return

    if m.home <> invalid then
        m.home.openSearch = false
        m.home.visible = false
    end if

    ' Hide any other scenes that might be visible
    if m.details <> invalid then m.details.visible = false
    if m.library <> invalid then m.library.visible = false
    if m.player <> invalid then m.player.visible = false
    if m.settings <> invalid then m.settings.visible = false

    if m.search <> invalid then
        m.search.visible = true
        m.search.setFocus(true)

        ' Force focus to a known focusable list inside SearchScene if present
        results = m.search.findNode("results")
        if results <> invalid then results.setFocus(true)
    end if
end sub

sub onSearchBack(event as Object)
    if event <> invalid and event.getData() <> true then return

    if m.search <> invalid then
        m.search.backRequested = false
        m.search.visible = false
    end if
    showHome()
end sub

sub onPlayerBack(event as Object)
    if event <> invalid and event.getData() <> true then return

    if m.player <> invalid then
        m.player.backRequested = false
        m.player.visible = false
    end if
    showHome()
end sub

sub onDetailsBack(event as Object)
    if event <> invalid and event.getData() <> true then return

    if m.details <> invalid then
        m.details.backRequested = false
        m.details.visible = false
    end if
    showHome()
end sub

sub focusHomeDefault()
    if m.home = invalid then return

    ' Prefer the left nav if present
    nav = m.home.findNode("navList")
    if nav <> invalid then
        nav.setFocus(true)
        return
    end if

    ' Otherwise try the main rows
    rows = m.home.findNode("rows")
    if rows <> invalid then
        rows.setFocus(true)
        return
    end if

    ' Otherwise try a retry/action button group if present
    actions = m.home.findNode("connectionActions")
    if actions <> invalid then
        actions.setFocus(true)
        return
    end if
end sub
