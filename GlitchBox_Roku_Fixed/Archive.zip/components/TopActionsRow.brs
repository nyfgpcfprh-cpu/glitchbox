sub init()
    ' Defensive: ensure the component itself is visible and has a non-zero height
    if m.top <> invalid then
        m.top.visible = true
        if m.top.hasField("height") then m.top.height = 90
        if m.top.hasField("width") then m.top.width = 1000
    end if

    m.list = m.top.findNode("list")
    if m.list <> invalid then
        ' Defensive: ensure the internal grid is visible and has non-zero size
        m.list.visible = true
        if m.list.hasField("height") then m.list.height = 80
        if m.list.hasField("width") then m.list.width = 1000

        ' MarkupGrid uses itemComponentName (not rowItemComponentName)
        if m.list.hasField("itemComponentName") then m.list.itemComponentName = "TopActionItem"
        if m.list.hasField("itemSize") then m.list.itemSize = [200, 80]
        if m.list.hasField("itemSpacing") then m.list.itemSpacing = [20, 0]

        m.list.observeField("itemSelected", "onItemSelected")
    end if

    m.top.observeField("actions", "onActionsChanged")
    onActionsChanged()
end sub

sub onActionsChanged()
    actions = m.top.actions

    contentRoot = CreateObject("roSGNode", "ContentNode")

    if actions <> invalid then
        for each label in actions
            node = contentRoot.createChild("ContentNode")
            node.title = label
        end for
    end if

    if m.list <> invalid then
        m.list.content = contentRoot
    end if
end sub

sub onItemSelected(event as Object)
    selection = event.getData()
    if selection = invalid then return
    m.top.actionSelected = selection
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if press = false then return false

    ' LEFT -> return to left rail
    if key = "left" then
        scene = m.top.getScene()
        if scene <> invalid then
            home = scene.findNode("homeScene")
            if home <> invalid and home.visible then
                nav = home.findNode("navList")
                if nav <> invalid then
                    nav.setFocus(true)
                    return true
                end if
            end if
        end if
    end if

    ' DOWN -> go into the main rows
    if key = "down" then
        scene = m.top.getScene()
        if scene <> invalid then
            home = scene.findNode("homeScene")
            if home <> invalid and home.visible then
                rows = home.findNode("rows")
                if rows <> invalid then
                    rows.setFocus(true)
                    return true
                end if
            end if
        end if
    end if

    return false
end function
