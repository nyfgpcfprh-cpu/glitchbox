sub init()
    m.top.width = 900
    m.top.height = 80
    m.top.focusable = true
    m.top.itemComponentName = "TopActionItem"
    m.top.rowItemSize = [[200, 80]]
    m.top.rowHeights = [80]
    m.top.itemSpacing = [20, 0]
    m.top.rowItemSpacing = [[20, 0]]
    m.top.showRowLabel = [false]
    m.top.drawFocusFeedback = true
    m.top.vertFocusAnimationStyle = "floatingFocus"

    m.top.observeField("actions", "onActionsChanged")
    m.top.observeField("rowItemSelected", "onRowItemSelected")

    onActionsChanged()
end sub

sub onActionsChanged()
    actions = m.top.actions
    contentRoot = CreateObject("roSGNode", "ContentNode")
    row = contentRoot.createChild("ContentNode")

    if actions <> invalid then
        for each label in actions
            node = row.createChild("ContentNode")
            node.title = label
        end for
    end if

    m.top.content = contentRoot
end sub

sub onRowItemSelected(event as Object)
    selection = event.getData()
    if selection = invalid or selection.Count() < 2 then return
    m.top.actionSelected = selection[1]
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if press = false then return false

    if key = "left" then
        focused = m.top.itemFocused
        if focused = invalid or focused.Count() < 2 or focused[1] = 0 then
            scene = m.top.getScene()
            if scene <> invalid then
                home = scene.findNode("homeScene")
                if home <> invalid and home.visible = true then
                    nav = home.findNode("navList")
                    if nav <> invalid then
                        nav.setFocus(true)
                        return true
                    end if
                end if
            end if
        end if
    end if

    if key = "down" then
        scene = m.top.getScene()
        if scene <> invalid then
            home = scene.findNode("homeScene")
            if home <> invalid and home.visible = true then
                rows = home.findNode("rows")
                if rows <> invalid then
                    rows.setFocus(true)
                    return true
                end if
            end if
        end if
    end if

    return false
end function
